import React, { createContext, useContext, useState, useEffect } from 'react'
import type { Department, Laboratory, Experiment, UserRole } from '../types/lab'
import { INITIAL_DEPARTMENTS, INITIAL_LABORATORIES, INITIAL_EXPERIMENTS } from '../data/initialData'
import { isSupabaseConfigured } from '../lib/supabase'

interface LabStoreContextType {
  role: UserRole
  setRole: (role: UserRole) => void
  userEmail: string
  setUserEmail: (email: string) => void
  departments: Department[]
  laboratories: Laboratory[]
  experiments: Experiment[]
  addDepartment: (dept: Department) => void
  updateDepartment: (dept: Department) => void
  deleteDepartment: (id: string) => void
  addLaboratory: (lab: Laboratory) => void
  updateLaboratory: (lab: Laboratory) => void
  deleteLaboratory: (id: string) => void
  addExperiment: (exp: Experiment) => void
  updateExperiment: (exp: Experiment) => void
  deleteExperiment: (id: string) => void
  resetToFactoryDefaults: () => void
  supabaseConnected: boolean
}

const LabStoreContext = createContext<LabStoreContextType | undefined>(undefined)

const STORAGE_KEYS = {
  ROLE: 'vll_active_role_v1',
  DEPT: 'vll_departments_v1',
  LABS: 'vll_laboratories_v1',
  EXPS: 'vll_experiments_v1',
}

export function LabStoreProvider({ children }: { children: React.ReactNode }) {
  const [role, setRoleState] = useState<UserRole>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ROLE)
    return (saved as UserRole) || 'student'
  })

  const [userEmail, setUserEmail] = useState<string>('student@vlab.edu.in')

  const [departments, setDepartments] = useState<Department[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.DEPT)
    if (saved) {
      try { return JSON.parse(saved) } catch { /* fallback */ }
    }
    return INITIAL_DEPARTMENTS
  })

  const [laboratories, setLaboratories] = useState<Laboratory[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.LABS)
    if (saved) {
      try { return JSON.parse(saved) } catch { /* fallback */ }
    }
    return INITIAL_LABORATORIES
  })

  const [experiments, setExperiments] = useState<Experiment[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.EXPS)
    if (saved) {
      try { return JSON.parse(saved) } catch { /* fallback */ }
    }
    return INITIAL_EXPERIMENTS
  })

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ROLE, role)
  }, [role])

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.DEPT, JSON.stringify(departments))
  }, [departments])

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LABS, JSON.stringify(laboratories))
  }, [laboratories])

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.EXPS, JSON.stringify(experiments))
  }, [experiments])

  const setRole = (newRole: UserRole) => {
    setRoleState(newRole)
    if (newRole === 'public') setUserEmail('visitor@public.org')
    if (newRole === 'student') setUserEmail('student@vlab.edu.in')
    if (newRole === 'instructor') setUserEmail('instructor@vlab.edu.in')
    if (newRole === 'admin') setUserEmail('admin@vlab.edu.in')
  }

  const addDepartment = (dept: Department) => setDepartments((prev) => [...prev, dept])
  const updateDepartment = (dept: Department) =>
    setDepartments((prev) => prev.map((d) => (d.id === dept.id ? dept : d)))
  const deleteDepartment = (id: string) =>
    setDepartments((prev) => prev.filter((d) => d.id !== id))

  const addLaboratory = (lab: Laboratory) => setLaboratories((prev) => [...prev, lab])
  const updateLaboratory = (lab: Laboratory) =>
    setLaboratories((prev) => prev.map((l) => (l.id === lab.id ? lab : l)))
  const deleteLaboratory = (id: string) =>
    setLaboratories((prev) => prev.filter((l) => l.id !== id))

  const addExperiment = (exp: Experiment) => setExperiments((prev) => [...prev, exp])
  const updateExperiment = (exp: Experiment) =>
    setExperiments((prev) => prev.map((e) => (e.id === exp.id ? exp : e)))
  const deleteExperiment = (id: string) =>
    setExperiments((prev) => prev.filter((e) => e.id !== id))

  const resetToFactoryDefaults = () => {
    setDepartments(INITIAL_DEPARTMENTS)
    setLaboratories(INITIAL_LABORATORIES)
    setExperiments(INITIAL_EXPERIMENTS)
    localStorage.removeItem(STORAGE_KEYS.DEPT)
    localStorage.removeItem(STORAGE_KEYS.LABS)
    localStorage.removeItem(STORAGE_KEYS.EXPS)
  }

  return (
    <LabStoreContext.Provider
      value={{
        role,
        setRole,
        userEmail,
        setUserEmail,
        departments,
        laboratories,
        experiments,
        addDepartment,
        updateDepartment,
        deleteDepartment,
        addLaboratory,
        updateLaboratory,
        deleteLaboratory,
        addExperiment,
        updateExperiment,
        deleteExperiment,
        resetToFactoryDefaults,
        supabaseConnected: isSupabaseConfigured,
      }}
    >
      {children}
    </LabStoreContext.Provider>
  )
}

export function useLabStore() {
  const ctx = useContext(LabStoreContext)
  if (!ctx) throw new Error('useLabStore must be used within LabStoreProvider')
  return ctx
}
