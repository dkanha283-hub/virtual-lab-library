import { useState } from 'react'
import { Link } from 'react-router-dom'
import {
  Search,
  Zap,
  Cog,
  Building2,
  Radio,
  Terminal,
  Globe,
  FlaskConical,
  Gauge,
  Activity,
  HeartPulse,
  ArrowRight,
  Sparkles,
  Box,
  Sliders,
  ShieldCheck,
} from 'lucide-react'
import { useLabStore } from '../context/LabStoreContext'

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  Zap,
  Cog,
  Building2,
  Radio,
  Terminal,
  Globe,
  FlaskConical,
  Gauge,
  Activity,
  HeartPulse,
}

export function HomePage() {
  const { departments, laboratories, experiments, role } = useLabStore()
  const [searchQuery, setSearchQuery] = useState('')

  const visibleDepartments = departments.filter(
    (d) => d.published || role === 'admin' || role === 'instructor'
  )

  const filteredDepartments = visibleDepartments.filter(
    (d) =>
      d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.description.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const visibleExperiments = experiments.filter(
    (e) => e.published || role === 'admin' || role === 'instructor'
  )

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
      {/* Hero Banner */}
      <section className="relative rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-sky-950/60 border border-slate-800 p-6 sm:p-10 shadow-2xl overflow-hidden">
        <div className="max-w-3xl space-y-5">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-500/15 border border-sky-500/30 text-sky-300 text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            Central Digital Engineering Education Library
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
            Interactive 3D Engineering Labs &amp; Real-Time Simulations
          </h1>

          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            Explore <strong>{visibleDepartments.length} Engineering Departments</strong>, inspect 3D cutaways and exploded machine assemblies on your iPad, run SI-unit virtual laboratory simulations, and manage curriculum modules.
          </p>

          {/* Search Bar */}
          <div className="relative max-w-xl pt-2">
            <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2 mt-1" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search departments (e.g., Electrical, Mechanical, ECE, Civil)..."
              className="w-full pl-12 pr-4 py-3.5 rounded-2xl bg-slate-950/90 border border-slate-700 text-sm text-white placeholder:text-slate-400 focus:outline-none focus:border-sky-500"
            />
          </div>

          {/* Quick Jump Buttons */}
          <div className="flex flex-wrap gap-3 pt-2">
            <Link
              to="/experiment/speed-control-of-dc-shunt-motor"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-sky-600/25"
            >
              <Box className="w-4 h-4" />
              Launch 3D DC Shunt Motor Lab
            </Link>
            <Link
              to="/experiment/frequency-response-series-rlc-circuit"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 text-xs sm:text-sm font-bold"
            >
              <Sliders className="w-4 h-4 text-emerald-400" />
              Launch Series R-L-C Resonance Lab
            </Link>
            <Link
              to="/admin"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs sm:text-sm font-bold"
            >
              <ShieldCheck className="w-4 h-4" />
              Open Admin Content Manager
            </Link>
          </div>
        </div>
      </section>

      {/* All 10 Engineering Departments Grid */}
      <section className="space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
          <div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-white">
              Engineering Departments ({filteredDepartments.length})
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Select a department to browse its accredited laboratories and interactive experiments
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredDepartments.map((dept) => {
            const IconComp = ICON_MAP[dept.iconName] || Zap
            const deptLabs = laboratories.filter((l) => l.departmentId === dept.id)
            const deptExps = experiments.filter((e) => e.departmentId === dept.id)

            return (
              <Link
                key={dept.id}
                to={`/department/${dept.slug}`}
                className="group bg-slate-900/90 hover:bg-slate-900 border border-slate-800 hover:border-sky-500/50 rounded-2xl p-5 flex flex-col justify-between transition-all shadow-lg"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="w-11 h-11 rounded-xl bg-sky-500/15 border border-sky-500/30 flex items-center justify-center text-sky-400">
                      <IconComp className="w-5 h-5" />
                    </div>
                    <span className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono font-bold text-slate-300">
                      {dept.code}
                    </span>
                  </div>

                  <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-sky-300 transition-colors">
                    {dept.name}
                  </h3>

                  <p className="text-xs text-slate-400 leading-relaxed line-clamp-2">
                    {dept.description}
                  </p>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center justify-between text-xs">
                  <span className="text-slate-400">
                    <strong className="text-slate-200">{deptLabs.length}</strong> Labs •{' '}
                    <strong className="text-slate-200">{deptExps.length}</strong> Experiments
                  </span>
                  <span className="inline-flex items-center gap-1 font-bold text-sky-400 group-hover:translate-x-0.5 transition-transform">
                    Open Labs <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </Link>
            )
          })}
        </div>
      </section>

      {/* Featured Interactive Experiments */}
      <section className="space-y-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-white">
            Featured Interactive Experiments (17-Section Complete Modules)
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Includes Theory, Equations, Schematic Diagrams, Three.js 3D Models, Virtual Simulators, Viva &amp; Downloads
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {visibleExperiments.map((exp) => (
            <Link
              key={exp.id}
              to={`/experiment/${exp.slug}`}
              className="bg-slate-900/90 border border-slate-800 hover:border-emerald-500/50 rounded-2xl p-5 flex flex-col justify-between space-y-4 transition-all"
            >
              <div className="space-y-2.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="px-2.5 py-0.5 rounded-md bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 font-mono font-bold">
                    {exp.code}
                  </span>
                  <span className="text-slate-400">Sem {exp.semester} • {exp.difficulty}</span>
                </div>
                <h3 className="text-base font-bold text-white leading-snug">
                  {exp.title}
                </h3>
                <p className="text-xs text-slate-400 line-clamp-3 leading-relaxed">
                  {exp.summary}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs font-bold text-sky-400">
                <span>3D Model + Live Simulator</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  )
}
