import { useState } from 'react'
import {
  ShieldCheck,
  Plus,
  Trash2,
  Eye,
  EyeOff,
  ArrowUp,
  ArrowDown,
  RotateCcw,
  Upload,
  CheckCircle2,
  Layers,
  FlaskConical,
  Sliders,
} from 'lucide-react'
import { useLabStore } from '../context/LabStoreContext'
import { DEFAULT_SECTIONS_CONFIG } from '../data/initialData'
import type { ModelPresetId, SimulationPresetId } from '../types/lab'

export function AdminPage() {
  const {
    role,
    setRole,
    departments,
    laboratories,
    experiments,
    addDepartment,
    deleteDepartment,
    addLaboratory,
    deleteLaboratory,
    addExperiment,
    updateExperiment,
    deleteExperiment,
    resetToFactoryDefaults,
  } = useLabStore()

  const [activeTab, setActiveTab] = useState<'departments' | 'labs' | 'experiments' | 'sections'>('departments')
  const [statusBanner, setStatusBanner] = useState<string>('')

  // New Department Form State
  const [deptName, setDeptName] = useState('')
  const [deptCode, setDeptCode] = useState('')
  const [deptDesc, setDeptDesc] = useState('')

  // New Lab Form State
  const [labName, setLabName] = useState('')
  const [labCode, setLabCode] = useState('')
  const [labDeptId, setLabDeptId] = useState(departments[0]?.id || 'dept-ee')
  const [labSem, setLabSem] = useState(3)
  const [labRoom, setLabRoom] = useState('Block B - Room 201')

  // New Experiment Form State
  const [expTitle, setExpTitle] = useState('')
  const [expCode, setExpCode] = useState('')
  const [expLabId, setExpLabId] = useState(laboratories[0]?.id || 'lab-ee-em1')
  const [expModelPreset, setExpModelPreset] = useState<ModelPresetId>('dc-shunt-motor')
  const [expSimPreset, setExpSimPreset] = useState<SimulationPresetId>('dc-motor-speed-control')

  // Selected Experiment for Section Reordering & Uploads
  const [selectedExpId, setSelectedExpId] = useState(experiments[0]?.id || '')
  const selectedExp = experiments.find((e) => e.id === selectedExpId) || experiments[0]

  const [newResourceTitle, setNewResourceTitle] = useState('')
  const [newResourceType, setNewResourceType] = useState<'PDF' | 'PPTX' | 'GLB' | 'VIDEO'>('PDF')

  if (role !== 'admin' && role !== 'instructor') {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center space-y-5">
        <div className="w-16 h-16 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center mx-auto text-amber-400">
          <ShieldCheck className="w-8 h-8" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
          Administrator or Instructor Access Required
        </h1>
        <p className="text-sm text-slate-400 max-w-xl mx-auto">
          You are currently browsing as <strong className="text-white uppercase">{role}</strong>. Tap the button below to switch your active session role to <strong>Administrator</strong> and unlock full department, laboratory, 3D model, and section management.
        </p>
        <button
          onClick={() => setRole('admin')}
          className="px-6 py-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-sm shadow-lg cursor-pointer"
        >
          Unlock Admin Content Management Portal Now
        </button>
      </div>
    )
  }

  const handleCreateDepartment = (e: React.FormEvent) => {
    e.preventDefault()
    if (!deptName.trim() || !deptCode.trim()) return
    const slug = deptName.toLowerCase().replace(/[^a-z0-9]+/g, '-')
    addDepartment({
      id: `dept-${Date.now()}`,
      slug,
      code: deptCode.toUpperCase(),
      name: deptName.trim(),
      shortName: `${deptName.trim()} (${deptCode.toUpperCase()})`,
      description: deptDesc.trim() || 'Accredited engineering department virtual laboratory.',
      iconName: 'Zap',
      accentColor: 'sky',
      published: true,
    })
    setDeptName('')
    setDeptCode('')
    setDeptDesc('')
    setStatusBanner(`Created department "${deptName}"!`)
  }

  const handleCreateLab = (e: React.FormEvent) => {
    e.preventDefault()
    if (!labName.trim() || !labCode.trim()) return
    const slug = labName.toLowerCase().replace(/[^a-z0-9]+/g, '-')
    addLaboratory({
      id: `lab-${Date.now()}`,
      slug,
      code: labCode.toUpperCase(),
      name: labName.trim(),
      departmentId: labDeptId,
      semester: labSem,
      description: `Virtual and physical laboratory for ${labName.trim()}.`,
      incharge: 'Prof. Faculty In-Charge',
      roomNumber: labRoom,
      published: true,
    })
    setLabName('')
    setLabCode('')
    setStatusBanner(`Created laboratory "${labName}"!`)
  }

  const handleCreateExperiment = (e: React.FormEvent) => {
    e.preventDefault()
    if (!expTitle.trim() || !expCode.trim()) return
    const parentLab = laboratories.find((l) => l.id === expLabId) || laboratories[0]
    const slug = expTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-')
    addExperiment({
      id: `exp-${Date.now()}`,
      slug,
      code: expCode.toUpperCase(),
      title: expTitle.trim(),
      labId: parentLab.id,
      departmentId: parentLab.departmentId,
      semester: parentLab.semester,
      difficulty: 'Intermediate',
      estimatedMinutes: 90,
      published: true,
      summary: `Interactive 3D and virtual simulation experiment for ${expTitle.trim()}.`,
      aim: `To study and verify the characteristics of ${expTitle.trim()}.`,
      objectives: ['Verify theoretical equations with real-time simulation data.', 'Inspect 3D assembly components.'],
      learningOutcomes: ['Ability to conduct virtual test and plot characteristic curves.'],
      apparatus: [{ name: 'Standard Test Workbench', specification: 'Calibrated SI Unit Rig', quantity: 1 }],
      theory: 'Standard engineering theory and governing analytical relationships.',
      equations: [{ label: 'Primary Relation', formula: 'Y = k · X', variables: 'Standard SI variables' }],
      circuitDiagramSvgType: 'dc-shunt',
      circuitDiagramDescription: 'Standard laboratory schematic diagram.',
      model3dPreset: expModelPreset,
      simulationPreset: expSimPreset,
      procedure: ['Configure parameters on the simulator.', 'Record observations in the table.'],
      sampleCalculations: 'Verified with standard SI unit test points.',
      resultsTemplate: 'Experimental characteristics matched theoretical predictions.',
      precautions: ['Verify rated limits before energizing the workbench.'],
      vivaQuestions: [{ id: 'vq-1', question: 'What is the main objective of this experiment?', answer: 'To experimentally verify the governing mathematical model.' }],
      references: ['Standard B.Tech Engineering Laboratory Manual'],
      downloads: [],
      sectionsConfig: DEFAULT_SECTIONS_CONFIG,
    })
    setExpTitle('')
    setExpCode('')
    setStatusBanner(`Created experiment "${expTitle}" with 3D Viewer & Simulator!`)
  }

  const toggleSection = (sectionId: string) => {
    if (!selectedExp) return
    const updated = selectedExp.sectionsConfig.map((sec) =>
      sec.id === sectionId ? { ...sec, enabled: !sec.enabled } : sec
    )
    updateExperiment({ ...selectedExp, sectionsConfig: updated })
  }

  const moveSection = (index: number, direction: -1 | 1) => {
    if (!selectedExp) return
    const sorted = [...selectedExp.sectionsConfig].sort((a, b) => a.order - b.order)
    const targetIdx = index + direction
    if (targetIdx < 0 || targetIdx >= sorted.length) return
    const tempOrder = sorted[index].order
    sorted[index].order = sorted[targetIdx].order
    sorted[targetIdx].order = tempOrder
    updateExperiment({ ...selectedExp, sectionsConfig: sorted })
  }

  const handleAddResource = (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedExp || !newResourceTitle.trim()) return
    const newDl = {
      id: `dl-${Date.now()}`,
      title: newResourceTitle.trim(),
      fileType: newResourceType,
      fileSize: '2.1 MB',
      url: '#uploaded-resource',
      requiresAuth: true,
    }
    updateExperiment({
      ...selectedExp,
      downloads: [...selectedExp.downloads, newDl],
    })
    setNewResourceTitle('')
    setStatusBanner(`Attached ${newResourceType} resource to ${selectedExp.code}!`)
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-300 text-xs font-bold uppercase">
            Role: {role} • Full Content Management System
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-2">
            Admin Content &amp; Curriculum Manager
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">
            Create departments, laboratories, experiments, reorder the 17 experiment sections, and attach PDF/3D GLB resources.
          </p>
        </div>

        <button
          onClick={() => {
            resetToFactoryDefaults()
            setStatusBanner('Restored factory default departments, labs, and experiments.')
          }}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-bold text-slate-300 hover:text-white cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" />
          Reset Demo Data
        </button>
      </div>

      {statusBanner && (
        <div className="p-4 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-xs sm:text-sm text-emerald-200 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{statusBanner}</span>
        </div>
      )}

      {/* Touch Tab Selector */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <button
          onClick={() => setActiveTab('departments')}
          className={`p-3.5 rounded-xl text-xs sm:text-sm font-bold border flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'departments'
              ? 'bg-sky-600 text-white border-sky-500'
              : 'bg-slate-900 text-slate-300 border-slate-800'
          }`}
        >
          <Layers className="w-4 h-4" />
          1. Departments ({departments.length})
        </button>
        <button
          onClick={() => setActiveTab('labs')}
          className={`p-3.5 rounded-xl text-xs sm:text-sm font-bold border flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'labs'
              ? 'bg-sky-600 text-white border-sky-500'
              : 'bg-slate-900 text-slate-300 border-slate-800'
          }`}
        >
          <FlaskConical className="w-4 h-4" />
          2. Laboratories ({laboratories.length})
        </button>
        <button
          onClick={() => setActiveTab('experiments')}
          className={`p-3.5 rounded-xl text-xs sm:text-sm font-bold border flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'experiments'
              ? 'bg-sky-600 text-white border-sky-500'
              : 'bg-slate-900 text-slate-300 border-slate-800'
          }`}
        >
          <Sliders className="w-4 h-4" />
          3. Experiments ({experiments.length})
        </button>
        <button
          onClick={() => setActiveTab('sections')}
          className={`p-3.5 rounded-xl text-xs sm:text-sm font-bold border flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'sections'
              ? 'bg-sky-600 text-white border-sky-500'
              : 'bg-slate-900 text-slate-300 border-slate-800'
          }`}
        >
          <Upload className="w-4 h-4" />
          4. Section Order &amp; Uploads
        </button>
      </div>

      {/* TAB 1: DEPARTMENTS */}
      {activeTab === 'departments' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <form
            onSubmit={handleCreateDepartment}
            className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4"
          >
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Plus className="w-4 h-4 text-sky-400" />
              Add New Engineering Department
            </h2>
            <div>
              <label className="text-xs text-slate-400 block mb-1">Department Name</label>
              <input
                type="text"
                required
                placeholder="e.g., Aerospace Engineering"
                value={deptName}
                onChange={(e) => setDeptName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white"
              />
            </div>
            <div>
              <label className="text-xs text-slate-400 block mb-1">Short Code</label>
              <input
                type="text"
                required
                placeholder="e.g., AE"
                value={deptCode}
                onChange={(e) => setDeptCode(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white"
              />
            </div>
            <div>
              <label className="text-xs text-slate-400 block mb-1">Description</label>
              <textarea
                rows={3}
                placeholder="Aerodynamics, Propulsion, and Avionics laboratories..."
                value={deptDesc}
                onChange={(e) => setDeptDesc(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white"
              />
            </div>
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs uppercase tracking-wider cursor-pointer"
            >
              Create Department
            </button>
          </form>

          <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-3">
            <h2 className="text-base font-bold text-white">Existing Departments</h2>
            <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
              {departments.map((d) => (
                <div
                  key={d.id}
                  className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3"
                >
                  <div>
                    <div className="text-sm font-bold text-white">
                      {d.name} <span className="text-xs font-mono text-sky-400">({d.code})</span>
                    </div>
                    <p className="text-xs text-slate-400 line-clamp-1">{d.description}</p>
                  </div>
                  <button
                    onClick={() => deleteDepartment(d.id)}
                    className="p-2 rounded-lg bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 cursor-pointer"
                    title="Delete Department"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: LABORATORIES */}
      {activeTab === 'labs' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <form
            onSubmit={handleCreateLab}
            className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4"
          >
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Plus className="w-4 h-4 text-emerald-400" />
              Create New Laboratory
            </h2>
            <div>
              <label className="text-xs text-slate-400 block mb-1">Parent Department</label>
              <select
                value={labDeptId}
                onChange={(e) => setLabDeptId(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white"
              >
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-xs text-slate-400 block mb-1">Laboratory Name</label>
              <input
                type="text"
                required
                placeholder="e.g., Power Electronics & Drives Lab"
                value={labName}
                onChange={(e) => setLabName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-slate-400 block mb-1">Course Code</label>
                <input
                  type="text"
                  required
                  placeholder="EEPC-502"
                  value={labCode}
                  onChange={(e) => setLabCode(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white"
                />
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">Semester</label>
                <input
                  type="number"
                  min={1}
                  max={8}
                  value={labSem}
                  onChange={(e) => setLabSem(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white"
                />
              </div>
            </div>
            <div>
              <label className="text-xs text-slate-400 block mb-1">Room / Hall Location</label>
              <input
                type="text"
                value={labRoom}
                onChange={(e) => setLabRoom(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white"
              />
            </div>
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider cursor-pointer"
            >
              Add Laboratory
            </button>
          </form>

          <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-3">
            <h2 className="text-base font-bold text-white">Active Laboratories</h2>
            <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
              {laboratories.map((l) => (
                <div
                  key={l.id}
                  className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3"
                >
                  <div>
                    <div className="text-sm font-bold text-white">
                      {l.name} <span className="text-xs font-mono text-emerald-400">({l.code})</span>
                    </div>
                    <p className="text-xs text-slate-400">Semester {l.semester} • {l.roomNumber}</p>
                  </div>
                  <button
                    onClick={() => deleteLaboratory(l.id)}
                    className="p-2 rounded-lg bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: EXPERIMENTS */}
      {activeTab === 'experiments' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <form
            onSubmit={handleCreateExperiment}
            className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4"
          >
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Plus className="w-4 h-4 text-sky-400" />
              Create New Experiment with 3D &amp; Simulator
            </h2>
            <div>
              <label className="text-xs text-slate-400 block mb-1">Assign to Laboratory</label>
              <select
                value={expLabId}
                onChange={(e) => setExpLabId(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white"
              >
                {laboratories.map((l) => (
                  <option key={l.id} value={l.id}>{l.name} ({l.code})</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-xs text-slate-400 block mb-1">Experiment Title</label>
              <input
                type="text"
                required
                placeholder="e.g., Open Circuit & Short Circuit Test on 1-Phase Transformer"
                value={expTitle}
                onChange={(e) => setExpTitle(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white"
              />
            </div>
            <div>
              <label className="text-xs text-slate-400 block mb-1">Experiment Code</label>
              <input
                type="text"
                required
                placeholder="EM1-EXP-05"
                value={expCode}
                onChange={(e) => setExpCode(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white"
              />
            </div>
            <div>
              <label className="text-xs text-slate-400 block mb-1">3D Engineering Model Preset</label>
              <select
                value={expModelPreset}
                onChange={(e) => setExpModelPreset(e.target.value as ModelPresetId)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white"
              >
                <option value="dc-shunt-motor">4-Pole DC Shunt Machine Assembly</option>
                <option value="rlc-workbench">Series R-L-C &amp; Dual-Trace CRO Workbench</option>
                <option value="centrifugal-pump">Single-Stage Volute Centrifugal Pump</option>
                <option value="three-phase-induction">3-Phase Squirrel-Cage Induction Motor</option>
              </select>
            </div>
            <div>
              <label className="text-xs text-slate-400 block mb-1">Simulation Engine Preset</label>
              <select
                value={expSimPreset}
                onChange={(e) => setExpSimPreset(e.target.value as SimulationPresetId)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white"
              >
                <option value="dc-motor-speed-control">DC Shunt Motor Speed Control Solver</option>
                <option value="series-rlc-resonance">Series R-L-C Frequency Response Solver</option>
                <option value="bernoulli-flow-rig">Centrifugal Pump Head &amp; Efficiency Solver</option>
              </select>
            </div>
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs uppercase tracking-wider cursor-pointer"
            >
              Publish New Experiment
            </button>
          </form>

          <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-3">
            <h2 className="text-base font-bold text-white">Published Experiments</h2>
            <div className="space-y-2">
              {experiments.map((ex) => (
                <div
                  key={ex.id}
                  className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3"
                >
                  <div>
                    <div className="text-sm font-bold text-white">
                      {ex.title} <span className="text-xs font-mono text-sky-400">({ex.code})</span>
                    </div>
                    <p className="text-xs text-slate-400">
                      3D Model: {ex.model3dPreset} • Simulator: {ex.simulationPreset}
                    </p>
                  </div>
                  <button
                    onClick={() => deleteExperiment(ex.id)}
                    className="p-2 rounded-lg bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: REORDER 17 SECTIONS & UPLOAD RESOURCES */}
      {activeTab === 'sections' && selectedExp && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <h2 className="text-base font-bold text-white">
                Configure &amp; Reorder 17 Experiment Sections
              </h2>
              <select
                value={selectedExp.id}
                onChange={(e) => setSelectedExpId(e.target.value)}
                className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white"
              >
                {experiments.map((e) => (
                  <option key={e.id} value={e.id}>{e.code}: {e.title}</option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5 max-h-[420px] overflow-y-auto pr-1">
              {[...selectedExp.sectionsConfig]
                .sort((a, b) => a.order - b.order)
                .map((sec, idx) => (
                  <div
                    key={sec.id}
                    className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2"
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="text-xs font-mono text-slate-400 w-6">#{idx + 1}</span>
                      <span className={sec.enabled ? 'text-xs font-bold text-white' : 'text-xs line-through text-slate-500'}>
                        {sec.title}
                      </span>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => moveSection(idx, -1)}
                        className="p-1.5 rounded-lg bg-slate-900 text-slate-300 hover:text-white cursor-pointer"
                        title="Move Section Up"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => moveSection(idx, 1)}
                        className="p-1.5 rounded-lg bg-slate-900 text-slate-300 hover:text-white cursor-pointer"
                        title="Move Section Down"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => toggleSection(sec.id)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer ${
                          sec.enabled
                            ? 'bg-emerald-500/15 text-emerald-300'
                            : 'bg-rose-500/15 text-rose-300'
                        }`}
                      >
                        {sec.enabled ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                        {sec.enabled ? 'Shown' : 'Hidden'}
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          </div>

          {/* Upload PDF / PPTX / GLB 3D Asset */}
          <form
            onSubmit={handleAddResource}
            className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4"
          >
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Upload className="w-4 h-4 text-sky-400" />
              Attach Lab Manual PDF, Presentation, or .GLB 3D Model
            </h2>
            <div>
              <label className="text-xs text-slate-400 block mb-1">Resource Title</label>
              <input
                type="text"
                required
                placeholder="e.g., Complete Lab Viva & Circuit Workbook"
                value={newResourceTitle}
                onChange={(e) => setNewResourceTitle(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white"
              />
            </div>
            <div>
              <label className="text-xs text-slate-400 block mb-1">File Format</label>
              <select
                value={newResourceType}
                onChange={(e) => setNewResourceType(e.target.value as 'PDF' | 'PPTX' | 'GLB' | 'VIDEO')}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white"
              >
                <option value="PDF">PDF Document (.pdf)</option>
                <option value="PPTX">Lecture Presentation (.pptx)</option>
                <option value="GLB">Three.js 3D CAD Model (.glb / .gltf)</option>
                <option value="VIDEO">Lab Demonstration Video (.mp4)</option>
              </select>
            </div>
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs uppercase tracking-wider cursor-pointer"
            >
              Attach Resource to {selectedExp.code}
            </button>
          </form>
        </div>
      )}
    </div>
  )
}
