import { Link, useParams } from 'react-router-dom'
import { ArrowLeft, ArrowRight, BookOpen, Layers } from 'lucide-react'
import { useLabStore } from '../context/LabStoreContext'

export function DepartmentPage() {
  const { deptSlug } = useParams()
  const { departments, laboratories, experiments } = useLabStore()

  const dept = departments.find((d) => d.slug === deptSlug) || departments[0]
  const deptLabs = laboratories.filter((l) => l.departmentId === dept.id)

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <Link
        to="/"
        className="inline-flex items-center gap-2 text-xs font-bold text-sky-400 hover:text-sky-300"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to All Engineering Departments
      </Link>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/15 text-sky-300 text-xs font-mono font-bold">
          Department Code: {dept.code}
        </div>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-white">{dept.name}</h1>
        <p className="text-sm sm:text-base text-slate-300 max-w-3xl leading-relaxed">
          {dept.description}
        </p>
      </div>

      <div className="space-y-4">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Layers className="w-5 h-5 text-sky-400" />
          Laboratories in {dept.shortName} ({deptLabs.length})
        </h2>

        {deptLabs.length === 0 ? (
          <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-8 text-center space-y-3">
            <p className="text-sm text-slate-300">
              No laboratories have been added to {dept.name} yet.
            </p>
            <Link
              to="/admin"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-sky-600 text-white text-xs font-bold"
            >
              Add a Laboratory in Admin Portal
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {deptLabs.map((lab) => {
              const labExps = experiments.filter((e) => e.labId === lab.id)
              return (
                <Link
                  key={lab.id}
                  to={`/laboratory/${lab.slug}`}
                  className="bg-slate-900 border border-slate-800 hover:border-sky-500/50 rounded-2xl p-6 flex flex-col justify-between space-y-4 transition-all"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="px-2.5 py-1 rounded-md bg-sky-500/15 text-sky-300 font-mono font-bold">
                        {lab.code}
                      </span>
                      <span className="text-slate-400">
                        Semester {lab.semester} • {lab.roomNumber}
                      </span>
                    </div>
                    <h3 className="text-lg font-bold text-white">{lab.name}</h3>
                    <p className="text-xs text-slate-400 leading-relaxed">{lab.description}</p>
                  </div>

                  <div className="pt-4 border-t border-slate-800 flex items-center justify-between text-xs">
                    <span className="text-slate-300 flex items-center gap-1.5">
                      <BookOpen className="w-4 h-4 text-emerald-400" />
                      {labExps.length} Experiments Available
                    </span>
                    <span className="font-bold text-sky-400 flex items-center gap-1">
                      Enter Lab <ArrowRight className="w-4 h-4" />
                    </span>
                  </div>
                </Link>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
