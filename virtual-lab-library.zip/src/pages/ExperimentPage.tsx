import { useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import {
  BookOpen,
  CheckCircle2,
  Cpu,
  Download,
  Lock,
  HelpCircle,
  AlertTriangle,
  FileText,
  Calculator,
  Compass,
} from 'lucide-react'
import { useLabStore } from '../context/LabStoreContext'
import { Engineering3DViewer } from '../components/viewer3d/Engineering3DViewer'
import { VirtualLabSimulator } from '../components/simulation/VirtualLabSimulator'

export function ExperimentPage() {
  const { expSlug } = useParams()
  const { experiments, laboratories, departments, role, setRole } = useLabStore()
  const [liveRpm, setLiveRpm] = useState<number>(1500)
  const [downloadNotice, setDownloadNotice] = useState<string>('')

  const exp = experiments.find((e) => e.slug === expSlug) || experiments[0]
  const lab = laboratories.find((l) => l.id === exp.labId)
  const dept = departments.find((d) => d.id === exp.departmentId)

  const enabledSections = [...exp.sectionsConfig]
    .filter((s) => s.enabled)
    .sort((a, b) => a.order - b.order)

  const isEnabled = (id: string) => enabledSections.some((s) => s.id === id)

  const handleDownload = (title: string, requiresAuth: boolean) => {
    if (requiresAuth && role === 'public') {
      setDownloadNotice(
        `Protected Resource: "${title}" requires Student, Instructor, or Admin login. Tap "Student" in the top bar to unlock.`
      )
      return
    }
    // Generate clean educational summary sheet download right in iPad Safari
    const content = `VIRTUAL LAB LIBRARY — OFFICIAL LAB HANDOUT
Experiment Code: ${exp.code}
Title: ${exp.title}
Department: ${dept?.name || 'Engineering'}
Laboratory: ${lab?.name || 'Laboratory'}

1. AIM:
${exp.aim}

2. THEORY:
${exp.theory}

3. SAMPLE CALCULATIONS:
${exp.sampleCalculations}

4. PRECAUTIONS:
${exp.precautions.map((p, i) => `${i + 1}. ${p}`).join('\n')}
`
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${exp.code}-${title.replace(/[^a-zA-Z0-9]/g, '_')}.txt`
    a.click()
    URL.revokeObjectURL(url)
    setDownloadNotice(`Downloaded "${title}" successfully!`)
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* Breadcrumb Navigation */}
      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
        <Link to="/" className="hover:text-white">Home</Link>
        <span>/</span>
        {dept && (
          <>
            <Link to={`/department/${dept.slug}`} className="text-sky-400 hover:underline">
              {dept.shortName}
            </Link>
            <span>/</span>
          </>
        )}
        {lab && (
          <>
            <Link to={`/laboratory/${lab.slug}`} className="text-sky-400 hover:underline">
              {lab.name}
            </Link>
            <span>/</span>
          </>
        )}
        <span className="text-slate-200 font-mono font-bold">{exp.code}</span>
      </div>

      {/* Experiment Title Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-4 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="px-3 py-1 rounded-full bg-sky-500/15 border border-sky-500/30 text-sky-300 text-xs font-mono font-bold">
            {exp.code} • Semester {exp.semester} • {exp.difficulty}
          </span>
          <span className="text-xs text-slate-400">
            Active Sections: <strong className="text-white">{enabledSections.length} / 17</strong>
          </span>
        </div>

        <h1 className="text-2xl sm:text-3xl font-extrabold text-white leading-tight">
          {exp.title}
        </h1>
        <p className="text-sm text-slate-300 leading-relaxed">{exp.summary}</p>

        {/* Quick Section Jump Pills for iPad Touch */}
        <div className="pt-2 flex flex-wrap gap-1.5">
          {enabledSections.map((sec) => (
            <a
              key={sec.id}
              href={`#sec-${sec.id}`}
              className="px-2.5 py-1 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-[11px] font-medium text-slate-300"
            >
              {sec.title}
            </a>
          ))}
        </div>
      </div>

      {/* 1. Aim & Objectives + 2. Learning Outcomes */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {isEnabled('aim') && (
          <section
            id="sec-aim"
            className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-3"
          >
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Compass className="w-5 h-5 text-sky-400" />
              1. Aim &amp; Experimental Objectives
            </h2>
            <p className="text-sm text-slate-200 font-medium leading-relaxed bg-slate-950 p-3.5 rounded-xl border border-slate-800">
              {exp.aim}
            </p>
            <ul className="space-y-2 pt-1">
              {exp.objectives.map((obj, i) => (
                <li key={i} className="flex items-start gap-2 text-xs sm:text-sm text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                  <span>{obj}</span>
                </li>
              ))}
            </ul>
          </section>
        )}

        {isEnabled('outcomes') && (
          <section
            id="sec-outcomes"
            className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-3"
          >
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-emerald-400" />
              2. Course Learning Outcomes (COs)
            </h2>
            <ul className="space-y-2.5">
              {exp.learningOutcomes.map((co, i) => (
                <li
                  key={i}
                  className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs sm:text-sm text-slate-300 leading-relaxed"
                >
                  {co}
                </li>
              ))}
            </ul>
          </section>
        )}
      </div>

      {/* 3. Apparatus Required */}
      {isEnabled('apparatus') && (
        <section
          id="sec-apparatus"
          className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-4"
        >
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Cpu className="w-5 h-5 text-amber-400" />
            3. Laboratory Apparatus &amp; Instrument Specifications
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="py-2.5 px-3">Sl. No.</th>
                  <th className="py-2.5 px-3">Instrument / Equipment</th>
                  <th className="py-2.5 px-3">Rated Engineering Specification</th>
                  <th className="py-2.5 px-3">Qty</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70">
                {exp.apparatus.map((item, i) => (
                  <tr key={i} className="text-slate-200">
                    <td className="py-2.5 px-3 font-mono text-sky-400">{i + 1}</td>
                    <td className="py-2.5 px-3 font-semibold">{item.name}</td>
                    <td className="py-2.5 px-3 font-mono text-xs text-slate-300">
                      {item.specification}
                    </td>
                    <td className="py-2.5 px-3 font-bold">{item.quantity}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* 4. Theory & 5. Mathematical Equations */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {isEnabled('theory') && (
          <section
            id="sec-theory"
            className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-3"
          >
            <h2 className="text-lg font-bold text-white">4. Engineering Theory</h2>
            <div className="text-xs sm:text-sm text-slate-300 whitespace-pre-line leading-relaxed bg-slate-950 p-4 rounded-xl border border-slate-800">
              {exp.theory}
            </div>
          </section>
        )}

        {isEnabled('equations') && (
          <section
            id="sec-equations"
            className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-3"
          >
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Calculator className="w-5 h-5 text-sky-400" />
              5. Governing Equations
            </h2>
            <div className="space-y-3">
              {exp.equations.map((eq, i) => (
                <div
                  key={i}
                  className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5"
                >
                  <div className="text-xs font-bold text-sky-400">{eq.label}</div>
                  <div className="font-mono text-xs sm:text-sm font-bold text-white bg-slate-900 px-3 py-2 rounded-lg border border-slate-800">
                    {eq.formula}
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">{eq.variables}</p>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>

      {/* 6. Circuit / Schematic Diagram */}
      {isEnabled('circuit_diagram') && (
        <section
          id="sec-circuit_diagram"
          className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-4"
        >
          <div>
            <h2 className="text-lg font-bold text-white">
              6. Engineering Circuit / Workbench Schematic Diagram
            </h2>
            <p className="text-xs text-slate-400 mt-1">{exp.circuitDiagramDescription}</p>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col items-center">
            <svg viewBox="0 0 680 210" className="w-full max-w-3xl h-auto">
              <rect x="10" y="10" width="660" height="190" rx="14" fill="#090d16" stroke="#1e293b" strokeWidth="2" />
              {/* Supply Rails */}
              <line x1="50" y1="45" x2="580" y2="45" stroke="#38bdf8" strokeWidth="2.5" />
              <line x1="50" y1="165" x2="580" y2="165" stroke="#64748b" strokeWidth="2.5" />
              <circle cx="50" cy="45" r="5" fill="#38bdf8" />
              <circle cx="50" cy="165" r="5" fill="#64748b" />
              <text x="35" y="110" fill="#e2e8f0" fontSize="12" fontWeight="bold">
                {exp.circuitDiagramSvgType === 'series-rlc' ? 'V_s ∠0° (AC)' : '220V DC'}
              </text>

              {/* Branch 1: Rheostat / Resistor */}
              <rect x="150" y="33" width="95" height="24" rx="4" fill="#0f172a" stroke="#f59e0b" strokeWidth="2" />
              <text x="165" y="49" fill="#fcd34d" fontSize="11" fontWeight="bold">
                {exp.circuitDiagramSvgType === 'series-rlc' ? 'Resistor R' : 'Rheostat R_ext'}
              </text>

              {/* Branch 2: Field / Inductor */}
              <rect x="300" y="33" width="110" height="24" rx="4" fill="#0f172a" stroke="#10b981" strokeWidth="2" />
              <text x="315" y="49" fill="#6ee7b7" fontSize="11" fontWeight="bold">
                {exp.circuitDiagramSvgType === 'series-rlc' ? 'Inductor L (mH)' : 'Field R_f (Z-ZZ)'}
              </text>

              {/* Machine / Load Circle */}
              <line x1="500" y1="45" x2="500" y2="75" stroke="#38bdf8" strokeWidth="2.5" />
              <circle cx="500" cy="105" r="30" fill="#1e293b" stroke="#38bdf8" strokeWidth="2.5" />
              <text x="488" y="110" fill="#ffffff" fontSize="14" fontWeight="bold">
                {exp.circuitDiagramSvgType === 'series-rlc' ? 'C' : 'M'}
              </text>
              <line x1="500" y1="135" x2="500" y2="165" stroke="#64748b" strokeWidth="2.5" />

              {/* Voltmeter across load */}
              <line x1="580" y1="45" x2="580" y2="85" stroke="#a855f7" strokeWidth="2" />
              <circle cx="580" cy="105" r="18" fill="#0f172a" stroke="#a855f7" strokeWidth="2" />
              <text x="575" y="110" fill="#d8b4fe" fontSize="12" fontWeight="bold">V</text>
              <line x1="580" y1="125" x2="580" y2="165" stroke="#a855f7" strokeWidth="2" />
            </svg>
          </div>
        </section>
      )}

      {/* 7. Interactive 3D Engineering Model */}
      {isEnabled('model_3d') && (
        <section id="sec-model_3d" className="space-y-3">
          <h2 className="text-xl font-extrabold text-white">
            7. Interactive Three.js 3D Engineering Model (Cutaway, Exploded &amp; Inspector)
          </h2>
          <Engineering3DViewer
            preset={exp.model3dPreset}
            title={exp.title}
            rpm={liveRpm}
          />
        </section>
      )}

      {/* 8. Virtual Laboratory Simulation (Also covers 10. Observations & 12. Graphs) */}
      {isEnabled('simulation') && (
        <section id="sec-simulation" className="space-y-3">
          <h2 className="text-xl font-extrabold text-white">
            8. Virtual Laboratory Simulation, Live Graphs &amp; Observation Logger
          </h2>
          <VirtualLabSimulator
            preset={exp.simulationPreset}
            onRpmChange={(newRpm) => setLiveRpm(newRpm)}
          />
        </section>
      )}

      {/* 9. Procedure & 11. Sample Calculations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {isEnabled('procedure') && (
          <section
            id="sec-procedure"
            className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-3"
          >
            <h2 className="text-lg font-bold text-white">9. Step-by-Step Procedure</h2>
            <ol className="space-y-2.5">
              {exp.procedure.map((step, i) => (
                <li
                  key={i}
                  className="flex items-start gap-3 p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs sm:text-sm text-slate-300"
                >
                  <span className="w-6 h-6 rounded-full bg-sky-500/20 text-sky-300 font-bold text-xs flex items-center justify-center shrink-0">
                    {i + 1}
                  </span>
                  <span>{step}</span>
                </li>
              ))}
            </ol>
          </section>
        )}

        {isEnabled('calculations') && (
          <section
            id="sec-calculations"
            className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-4"
          >
            <h2 className="text-lg font-bold text-white">
              11. Sample Engineering Calculations &amp; 13. Results
            </h2>
            <div className="font-mono text-xs text-emerald-300 bg-slate-950 p-4 rounded-xl border border-slate-800 whitespace-pre-line leading-relaxed">
              {exp.sampleCalculations}
            </div>
            {isEnabled('results') && (
              <div className="p-4 rounded-xl bg-sky-500/10 border border-sky-500/30 space-y-1">
                <div className="text-xs font-bold uppercase text-sky-300">
                  13. Experimental Results &amp; Conclusion
                </div>
                <p className="text-xs sm:text-sm text-slate-200 whitespace-pre-line">
                  {exp.resultsTemplate}
                </p>
              </div>
            )}
          </section>
        )}
      </div>

      {/* 14. Precautions & 15. Viva Questions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {isEnabled('precautions') && (
          <section
            id="sec-precautions"
            className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-3"
          >
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-400" />
              14. Safety &amp; Laboratory Precautions
            </h2>
            <ul className="space-y-2">
              {exp.precautions.map((p, i) => (
                <li
                  key={i}
                  className="p-3 rounded-xl bg-slate-950 border border-amber-500/20 text-xs sm:text-sm text-slate-300"
                >
                  ⚠️ {p}
                </li>
              ))}
            </ul>
          </section>
        )}

        {isEnabled('viva') && (
          <section
            id="sec-viva"
            className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-3"
          >
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-purple-400" />
              15. Viva-Voce Questions &amp; Model Answers
            </h2>
            <div className="space-y-3">
              {exp.vivaQuestions.map((vq, i) => (
                <div
                  key={vq.id}
                  className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5"
                >
                  <div className="text-xs sm:text-sm font-bold text-white">
                    Q{i + 1}. {vq.question}
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">{vq.answer}</p>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>

      {/* 16. References & 17. Protected Downloadable Resources */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {isEnabled('references') && (
          <section
            id="sec-references"
            className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-3"
          >
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <FileText className="w-5 h-5 text-sky-400" />
              16. Standard References
            </h2>
            <ul className="space-y-2 text-xs text-slate-300 list-disc list-inside">
              {exp.references.map((ref, i) => (
                <li key={i} className="leading-relaxed">{ref}</li>
              ))}
            </ul>
          </section>
        )}

        {isEnabled('downloads') && (
          <section
            id="sec-downloads"
            className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-4"
          >
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Download className="w-5 h-5 text-emerald-400" />
                17. Downloadable Lab Manuals &amp; 3D Assets
              </h2>
              <span className="text-xs text-slate-400">
                Current Access Role: <strong className="text-sky-400 uppercase">{role}</strong>
              </span>
            </div>

            {downloadNotice && (
              <div className="p-3 rounded-xl bg-sky-500/15 border border-sky-500/40 text-xs text-sky-200 flex items-center justify-between gap-2">
                <span>{downloadNotice}</span>
                {role === 'public' && (
                  <button
                    onClick={() => setRole('student')}
                    className="px-2.5 py-1 rounded-lg bg-sky-600 text-white font-bold shrink-0 cursor-pointer"
                  >
                    Switch to Student
                  </button>
                )}
              </div>
            )}

            <div className="space-y-2.5">
              {exp.downloads.map((dl) => {
                const locked = dl.requiresAuth && role === 'public'
                return (
                  <div
                    key={dl.id}
                    className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
                        {dl.title}
                        <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-[10px] font-mono text-sky-300">
                          {dl.fileType} • {dl.fileSize}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        {dl.requiresAuth
                          ? 'Protected Resource (Requires Registered Student / Instructor / Admin)'
                          : 'Publicly Accessible Lab Sheet'}
                      </p>
                    </div>

                    <button
                      onClick={() => handleDownload(dl.title, dl.requiresAuth)}
                      className={
                        locked
                          ? 'inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-amber-500/40 text-amber-300 text-xs font-bold cursor-pointer shrink-0'
                          : 'inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold cursor-pointer shrink-0'
                      }
                    >
                      {locked ? <Lock className="w-3.5 h-3.5" /> : <Download className="w-3.5 h-3.5" />}
                      {locked ? 'Locked (Student Only)' : 'Download File'}
                    </button>
                  </div>
                )
              })}
            </div>
          </section>
        )}
      </div>
    </div>
  )
}
