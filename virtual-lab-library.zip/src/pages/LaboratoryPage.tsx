import { Link, useParams } from 'react-router-dom'
import { ArrowLeft, ArrowRight, FlaskConical, Clock, Award } from 'lucide-react'
import { useLabStore } from '../context/LabStoreContext'

export function LaboratoryPage() {
  const { labSlug } = useParams()
  const { laboratories, departments, experiments } = useLabStore()

  const lab = laboratories.find((l) => l.slug === labSlug) || laboratories[0]
  const dept = departments.find((d) => d.id === lab.departmentId)
  const labExps = experiments.filter((e) => e.labId === lab.id)

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
        <Link to="/" className="hover:text-white">Departments</Link>
        <span>/</span>
        {dept && (
          <>
            <Link to={`/department/${dept.slug}`} className="text-sky-400 hover:underline">
              {dept.name}
            </Link>
            <span>/</span>
          </>
        )}
        <span className="text-slate-200 font-semibold">{lab.name}</span>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-3">
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-300 font-mono font-bold">
            {lab.code}
          </span>
          <span className="px-3 py-1 rounded-full bg-slate-950 border border-slate-800 text-slate-300">
            Semester {lab.semester}
          </span>
          <span className="px-3 py-1 rounded-full bg-slate-950 border border-slate-800 text-slate-300">
            Location: {lab.roomNumber}
          </span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-white">{lab.name}</h1>
        <p className="text-sm sm:text-base text-slate-300 max-w-3xl">{lab.description}</p>
        <p className="text-xs text-slate-400 pt-1">
          <strong>Lab In-Charge:</strong> {lab.incharge}
        </p>
      </div>

      <div className="space-y-4">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <FlaskConical className="w-5 h-5 text-emerald-400" />
          Experiments in {lab.name} ({labExps.length})
        </h2>

        <div className="grid grid-cols-1 gap-4">
          {labExps.map((exp, idx) => (
            <Link
              key={exp.id}
              to={`/experiment/${exp.slug}`}
              className="bg-slate-900 border border-slate-800 hover:border-sky-500/50 rounded-2xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all"
            >
              <div className="space-y-2 max-w-3xl">
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <span className="px-2.5 py-0.5 rounded-md bg-sky-500/15 text-sky-300 font-mono font-bold">
                    Experiment #{idx + 1} • {exp.code}
                  </span>
                  <span className="flex items-center gap-1 text-slate-400">
                    <Clock className="w-3.5 h-3.5" /> {exp.estimatedMinutes} mins
                  </span>
                  <span className="flex items-center gap-1 text-amber-300">
                    <Award className="w-3.5 h-3.5" /> {exp.difficulty}
                  </span>
                </div>
                <h3 className="text-lg font-bold text-white">{exp.title}</h3>
                <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                  {exp.summary}
                </p>
              </div>

              <div className="shrink-0">
                <span className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-sky-600 text-white text-xs font-bold">
                  Open 3D Lab &amp; Simulator <ArrowRight className="w-4 h-4" />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>

      <Link
        to={dept ? `/department/${dept.slug}` : '/'}
        className="inline-flex items-center gap-2 text-xs font-bold text-slate-400 hover:text-white"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Department
      </Link>
    </div>
  )
}
