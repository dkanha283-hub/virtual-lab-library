import { Routes, Route, Link } from 'react-router-dom'
import { Navbar } from './components/layout/Navbar'
import { HomePage } from './pages/HomePage'
import { DepartmentPage } from './pages/DepartmentPage'
import { LaboratoryPage } from './pages/LaboratoryPage'
import { ExperimentPage } from './pages/ExperimentPage'
import { AdminPage } from './pages/AdminPage'

export default function App() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      <Navbar />
      <main className="flex-1">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/department/:deptSlug" element={<DepartmentPage />} />
          <Route path="/laboratory/:labSlug" element={<LaboratoryPage />} />
          <Route path="/experiment/:expSlug" element={<ExperimentPage />} />
          <Route path="/admin" element={<AdminPage />} />
        </Routes>
      </main>
      <footer className="border-t border-slate-800/80 bg-slate-950 py-6 px-4 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <span>
            <strong>Virtual Lab Library</strong> • Digital Engineering Education Platform (10 Departments • Three.js 3D • SI-Unit Simulators)
          </span>
          <div className="flex items-center gap-4">
            <Link to="/" className="hover:text-white">Departments</Link>
            <Link to="/experiment/speed-control-of-dc-shunt-motor" className="hover:text-white">DC Motor 3D</Link>
            <Link to="/experiment/frequency-response-series-rlc-circuit" className="hover:text-white">Series RLC</Link>
            <Link to="/admin" className="text-sky-400 hover:underline">Admin Portal</Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
