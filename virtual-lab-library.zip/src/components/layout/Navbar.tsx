import { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import {
  Cpu,
  Layers,
  ShieldCheck,
  Menu,
  X,
  Sliders,
  Box,
  Database,
  UserCheck,
} from 'lucide-react'
import { useLabStore } from '../../context/LabStoreContext'
import type { UserRole } from '../../types/lab'
import { cn } from '../../lib/utils'

const ROLE_OPTIONS: { id: UserRole; label: string; badgeColor: string }[] = [
  { id: 'public', label: 'Public Visitor', badgeColor: 'bg-slate-700 text-slate-200' },
  { id: 'student', label: 'Student', badgeColor: 'bg-sky-500/20 text-sky-300 border-sky-500/40' },
  { id: 'instructor', label: 'Instructor', badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/40' },
  { id: 'admin', label: 'Admin', badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' },
]

export function Navbar() {
  const { role, setRole, supabaseConnected } = useLabStore()
  const location = useLocation()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const navItems = [
    { to: '/', label: 'Home & Departments', icon: Layers },
    { to: '/experiment/speed-control-of-dc-shunt-motor', label: 'DC Motor 3D Lab', icon: Box },
    { to: '/experiment/frequency-response-series-rlc-circuit', label: 'Series RLC Lab', icon: Sliders },
    { to: '/admin', label: 'Admin & CMS Portal', icon: ShieldCheck },
  ]

  return (
    <header className="sticky top-0 z-50 bg-slate-950/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-3">
        {/* Brand Logo */}
        <Link to="/" className="flex items-center gap-3 group shrink-0">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-500 to-blue-600 flex items-center justify-center shadow-lg shadow-sky-500/20">
            <Cpu className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="font-extrabold text-base sm:text-lg tracking-tight text-white flex items-center gap-2">
              Virtual Lab Library
              <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-sky-500/15 text-sky-300 border border-sky-500/30">
                iPad Touch Ready
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              Department → Laboratory → 3D Model &amp; Simulation
            </p>
          </div>
        </Link>

        {/* Desktop / Landscape iPad Links */}
        <nav className="hidden lg:flex items-center gap-1.5">
          {navItems.map((item) => {
            const Icon = item.icon
            const active =
              item.to === '/'
                ? location.pathname === '/'
                : location.pathname.startsWith(item.to)
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  'flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all',
                  active
                    ? 'bg-sky-500/15 text-sky-300 border border-sky-500/40'
                    : 'text-slate-300 hover:bg-slate-900 hover:text-white'
                )}
              >
                <Icon className="w-4 h-4" />
                {item.label}
              </Link>
            )
          })}
        </nav>

        {/* Role Switcher Pill (For Instant Testing on iPad) */}
        <div className="flex items-center gap-2">
          <div className="hidden sm:flex items-center bg-slate-900 border border-slate-800 rounded-xl p-1 gap-1">
            <UserCheck className="w-3.5 h-3.5 text-slate-400 ml-2 mr-1" />
            {ROLE_OPTIONS.map((r) => (
              <button
                key={r.id}
                onClick={() => setRole(r.id)}
                className={cn(
                  'px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer',
                  role === r.id
                    ? 'bg-sky-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                )}
                title={`Switch active permission role to ${r.label}`}
              >
                {r.label}
              </button>
            ))}
          </div>

          <span
            className={cn(
              'hidden xl:inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] font-medium border',
              supabaseConnected
                ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                : 'bg-slate-900 text-slate-400 border-slate-800'
            )}
          >
            <Database className="w-3.5 h-3.5" />
            {supabaseConnected ? 'Supabase Live' : 'Local + Cloud Sync Ready'}
          </span>

          {/* Touch Menu Button for Portrait iPad / Mobile */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-200"
            aria-label="Toggle Menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Collapsible Touch Drawer for Portrait iPad */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-slate-900/95 border-b border-slate-800 px-4 py-4 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {navItems.map((item) => {
              const Icon = item.icon
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-2.5 px-4 py-3 rounded-xl bg-slate-950/80 border border-slate-800 text-sm font-semibold text-slate-200"
                >
                  <Icon className="w-4 h-4 text-sky-400" />
                  {item.label}
                </Link>
              )
            })}
          </div>

          <div className="pt-2 border-t border-slate-800">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
              Active Access Role (Tap to Switch):
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {ROLE_OPTIONS.map((r) => (
                <button
                  key={r.id}
                  onClick={() => {
                    setRole(r.id)
                    setMobileMenuOpen(false)
                  }}
                  className={cn(
                    'py-2.5 px-3 rounded-xl text-xs font-bold border text-center',
                    role === r.id
                      ? 'bg-sky-600 text-white border-sky-500'
                      : 'bg-slate-950 text-slate-400 border-slate-800'
                  )}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  )
}
